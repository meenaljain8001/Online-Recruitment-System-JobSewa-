import { Component, OnInit } from '@angular/core';
import { UsersService } from '../shared/users.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-log-out',
  templateUrl: './log-out.component.html',
  styleUrls: ['./log-out.component.css']
})
export class LogOutComponent implements OnInit {

  constructor(private usersService:UsersService,private routeBtn:Router,private toastr:ToastrService) { }

  ngOnInit(): void {
    this.usersService.loginUserId=null;
    this.usersService.userOrganization="";
    this.usersService.isAuthenticated=false;
    this.usersService.enableJobSeeker=false;
    this.usersService.enableJobPost=false;
    
    this.toastr.success("You have been Logged Out","Thank You");
    this.routeBtn.navigate(["/users/"]);
  }


}
