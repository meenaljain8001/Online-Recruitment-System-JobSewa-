import { NgModule } from '@angular/core';
import { Route, RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { UsersComponent } from './users/users.component';

import { JobSeekersComponent } from './job-seekers/job-seekers.component';
import { JobSeekerListComponent } from './job-seekers/job-seeker-list/job-seeker-list.component';
import { JobSeekerComponent } from './job-seekers/job-seeker/job-seeker.component';

import { JobPostListComponent } from './job-posts/job-post-list/job-post-list.component';
import { JobPostComponent } from './job-posts/job-post/job-post.component';
import { JobPostsComponent } from './job-posts/job-posts.component';
import { ApplyJobsComponent } from './apply-jobs/apply-jobs.component';
import { ListofJobSeekerComponent } from './listof-job-seeker/listof-job-seeker.component';
import { ResumedetailsComponent } from './job-seekers/resumedetails/resumedetails.component';
import { SearchByJobSeekerComponent } from './search-by-job-seeker/search-by-job-seeker.component';
import { SearchByJobPostComponent } from './search-by-job-post/search-by-job-post.component';
import { HeaderComponent } from './header/header.component';
import { LogOutComponent } from './log-out/log-out.component';



const appRoutes: Routes =[
  { path : 'Home', component: HomeComponent},
  {path : 'Home/:seekerID',component:HomeComponent},
  { path : 'users', component: UsersComponent,children:[
    {path : ':seekerID',component:UsersComponent},
    {path:':organizationName',component:UsersComponent}
  ]},
  {path : 'editSeekerDetails', component: JobSeekersComponent},
  {path : 'editJobPostDetails',component:JobPostsComponent},
  {path : 'deleteSeekerDetails', component: JobSeekerListComponent },
  {path : 'deletePostDetails', component: JobPostListComponent},
  {path : 'addSeekerDetails',component: JobSeekerComponent  },
  {path : 'jobseekersList',component:ListofJobSeekerComponent, },
  {path : 'jobPostsList',component:ApplyJobsComponent,children:[
    {path : ':seekerID',component:ApplyJobsComponent}
  ]},
  {path : 'contactUs',component:ContactUsComponent},
  {path : 'searchByJobSeeker',component:SearchByJobSeekerComponent},
  {path : 'searchByJobPost',component:SearchByJobPostComponent},
  {path : 'addJobPostDetails',component:JobPostComponent},
  {path : 'Users',component:UsersComponent},
  {path : 'resume',component:ResumedetailsComponent},
  {path: 'logOut',component:LogOutComponent},
  {path: '', redirectTo:'Home', pathMatch:'full'},
  

]

@NgModule({
  imports: [RouterModule.forRoot(appRoutes)],
  exports: [RouterModule]
})
export class AppRoutingModule {

  }

