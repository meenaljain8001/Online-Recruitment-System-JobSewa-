import { Component, OnInit } from '@angular/core';
import { JobSeekerService } from 'src/app/shared/job-seeker.service';
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { UsersService } from 'src/app/shared/users.service';
import { JobSeeker } from 'src/app/shared/job-seeker.model';

@Component({
  selector: 'app-job-seeker',
  templateUrl: './job-seeker.component.html',
  styleUrls: ['./job-seeker.component.css']
})
export class JobSeekerComponent implements OnInit {

  constructor(public service:JobSeekerService,
    private toastr:ToastrService, private http:HttpClient, private routerBtn:Router,private usersService: UsersService) { }

  ngOnInit() {
    this.resetForm();
  }

  resetForm(form?: NgForm) {
    if (form != null)
    {
      form.resetForm();
    }
      this.service.formData = {
      seekerId: null,
      seekerName: '',
      seekerAddress: '',
      seekerEmail :'',
    seekerPhoneNo :'',
    seekerPhoto :'',
    seekerXQualification:'',
    seekerXIIQualification:'',
    seekerHighestDegree:'',
    seekerSkills:'',
    seekerExperience:null,
    seekerProjects:''
    }
  }

seekerID:number;
  onSubmit(form: NgForm) {

    this.seekerID = form.value.seekerId;
   
    if (form.value.seekerId == null)
      this.insertRecord(form);
    else      
    if(this.usersService.loginUserId != null)
    {
      this.updateRecord(form);
    }
    else
    {
      this.toastr.warning("Please Login To Continue","Error");
      this.routerBtn.navigate(["/users/"])
    }
  }

  insertRecord(form: NgForm) {
    this.service.postJobSeeker(form.value).subscribe(res => {
      console.log(res["seekerId"]);
      
      alert("Your User Id for further login is : "+res["seekerId"]);
      this.toastr.success('Inserted successfully', 'Data Registered');
      this.resetForm(form);
      this.service.refreshList();     
      this.routerBtn.navigate(['/users/'+res["seekerId"]]);
    });
  }

  getSeekerDetailsById()
  {
    if(this.usersService.loginUserId)
    {
      this.service.getJobSeekerByID(this.usersService.loginUserId).subscribe(res=>{
        this.service.formData = Object.assign({}, res as JobSeeker);
      })
    }
    else{
      console.log("Enter Valid Seeker Id");
    }  
  }


  updateRecord(form: NgForm) {
    this.service.putJobSeeker(form.value).subscribe(res => {
    
      this.toastr.info('Updated successfully', 'Data updated');
      this.service.collapse=true;
      this.resetForm(form);
      this.service.formData = Object.assign({}, res as JobSeeker);
      this.getSeekerDetailsById();
    }

    );

   /* this.http.put('http://localhost:49754/api/JobSeekers/'+form.value.seekerId,form.value)
                                            .subscribe(res => {
                                              console.log("Inside Update ");
                                              console.log(res)
                                              this.toastr.info('Updated successfully', 'Data updated');
                                              this.resetForm(form);
                                              this.service.refreshList();
                                            });*/

    

  }

}
