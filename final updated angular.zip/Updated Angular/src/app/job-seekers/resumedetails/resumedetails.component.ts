import { Component, OnInit, Input } from '@angular/core';
import { JobSeekerService } from 'src/app/shared/job-seeker.service';
import { JobSeeker } from 'src/app/shared/job-seeker.model';
import { Route } from '@angular/compiler/src/core';
import { NavigationEnd, Event } from '@angular/router';
import { Router, RouterEvent} from '@angular/router';
import { UsersService } from 'src/app/shared/users.service';
import { Location } from '@angular/common';
@Component({
  selector: 'app-resumedetails',
  templateUrl: './resumedetails.component.html',
  styleUrls: ['./resumedetails.component.css']
})
export class ResumedetailsComponent implements OnInit {

  public previousUrl: string = undefined;
  private currentUrl: string = undefined;
private count:number=0;
  constructor(public service: JobSeekerService,public router: Router,private thirdservice:UsersService,private _location: Location) {     }

@Input('id') seekerId:number;

  ngOnInit(): void {
    
    this.getResumeDetails();
    console.log(this.seekerId);
    
    
  }


  backClicked() {
 
    this._location.back();
  }

  onClick()
  {
   
    console.log("previous url:",this.previousUrl);
    console.log("Current URL:",this.currentUrl);
    this.router.navigate([this.previousUrl+"/"]);
    
  }
  getResumeDetails(){
    this.service.getJobSeekerByID(this.seekerId).subscribe(res=>{
      console.log(res);
      this.service.formData=res as JobSeeker;
      console.log(this.service.formData);
    })
  }
  
}
