import { Component, OnInit } from '@angular/core';
import { JobSeekerService } from 'src/app/shared/job-seeker.service';
import { JobSeeker } from 'src/app/shared/job-seeker.model';
import { ToastrService } from 'ngx-toastr';
import { UsersService } from 'src/app/shared/users.service';


@Component({
  selector: 'app-job-seeker-list',
  templateUrl: './job-seeker-list.component.html',
  styleUrls: ['./job-seeker-list.component.css']
})
export class JobSeekerListComponent implements OnInit {

  formData:JobSeeker;

  constructor(public service:JobSeekerService,private toastr:ToastrService,private usersService:UsersService) { }
  
  ngOnInit(): void {
    this.getSeekerDetailsById();
  }

  populateForm(jobSeeker: JobSeeker) {
    this.service.formData = Object.assign({}, jobSeeker);
  
  }
  
  getSeekerDetailsById()
  {
    if(this.usersService.loginUserId)
    {
      this.service.getJobSeekerByID(this.usersService.loginUserId).subscribe(res=>{
        this.service.formData= Object.assign({}, res as JobSeeker);
        this.formData = Object.assign({}, res as JobSeeker);
      })
    }
    else{
      console.log("Enter Valid Seeker Id");
    }  
  }
  ToggleChanges()
  {
 this.getSeekerDetailsById();
    this.service.collapse = !this.service.collapse;
  }

// putSeekerDetailsById(id:number)
// {
//   this.service.formData=this.formData;
//   this.service.putJobSeeker(this.service.formData).subscribe(res =>{
//     console.log("Details Updated");
//     this.formData = this.service.formData;
//     this.getSeekerDetailsById();

//   })

// }

  onDelete(id: number) {
    if (confirm('Are you sure you want to delete this record?')) {
      this.service.deleteJobSeeker(id).subscribe(res => {
        this.toastr.warning('Deleted successfully', 'EMP. Register');
      });
    }
  }
}
