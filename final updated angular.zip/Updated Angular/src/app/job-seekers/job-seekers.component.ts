import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-job-seekers',
  templateUrl: './job-seekers.component.html',
  styleUrls: ['./job-seekers.component.css']
})
export class JobSeekersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    
  }

}
