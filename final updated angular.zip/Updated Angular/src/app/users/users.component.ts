import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { UsersService } from '../shared/users.service';
import { NgForm } from '@angular/forms';
import { Users } from '../shared/users.model';
import { Router } from '@angular/router';
import { JobSeekerService } from '../shared/job-seeker.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
  jobssingupemail;//required
  jobssinguppass;
  empsingupemail;
  empsignuppass;
  jobssingupName;
  empsingupName;
  jobsloginpass;
  emploginpass;
  jobsloginName;
  emploginName;
  jobtype;
 


  constructor(public service:UsersService,private ToastrService: ToastrService, private routerBtn:Router
    ,private jobSeekerService:JobSeekerService) { }

  ngOnInit(): void {
    this.resetForm();
  }
resetForm(form ?: NgForm){
  if(form !=null)
  {
    form.resetForm();
  }
  this.service.formData={
    userName:'',
    password:'',
    userType:'',
    userID:null
  }
}

  ValidJobSeekerSignUp(form:NgForm){
    if(form!=null)
    {
      form.value.userType="J";
      if(this.service.formData.userName == undefined || this.service.formData.userName == '' || this.jobssingupemail == undefined || this.jobssingupemail =='' || this.service.formData.password == undefined || this.service.formData.password == '' )
      {
        this.ToastrService.error( 'Please Fill Mandatory Fields','Signup Failed',{
          timeOut: 2000,
          positionClass: "md-toast-bottom-center",
        });
    }
    else{
      this.service.uType="J";
        this.service.createUser(form.value).subscribe(res => {
        this.resetForm(form);
       
        this.ToastrService.success('success', 'Signup Successful', {
          timeOut: 2000
      });
      this.service.userOrganization="";
      this.service.loginUserId=null;
      this.service.uType="";
      this.service.isAuthenticated=false;
      this.service.enableJobSeeker=false;
      this.service.enableJobPost=false;
      //this.routerBtn.navigate(['/Home/']);
      this.routerBtn.navigate(['/addSeekerDetails/']);
     });
  
    }
    }
    
}
  ValidEmployerSignUp(form:NgForm){
    if(form!=null)
    {
      form.value.userType="E"; 
      if(this.service.formData.userName == undefined || this.service.formData.userName == '' || this.empsingupemail == undefined || this.empsingupemail =='' || this.service.formData.password == undefined || this.service.formData.password == '' )
      {
        this.ToastrService.error( 'Please Fill Mandatory Fields', 'Fields Are Empty',{
          timeOut: 2000,
          positionClass: "md-toast-bottom-center",
     });
    }
    else{
      this.service.uType="E";
      this.service.createUser(form.value).subscribe(res => {
        this.resetForm(form)
        this.ToastrService.success('success', 'Signup Successful. Now Enter your credentials to Login ', {
          timeOut: 2000
      });
      this.service.userOrganization="";
      this.service.loginUserId=null;
      this.service.uType="";
      this.service.isAuthenticated=false;
      this.service.enableJobSeeker=false;
      this.service.enableJobPost=false;
      //this.routerBtn.navigate(['/Home/']);
      this.routerBtn.navigate(["/Home/"]);
     });
    }
    }
    
}
ValidJobSeekerSignIn(form:NgForm){
  if(form != null)
  {
    form.value.userType='J'; 
    if(this.service.loginUserId== undefined || this.service.loginUserId== null ||this.service.formData.userName == undefined || this.service.formData.userName == '' || this.service.formData.password == undefined || this.service.formData.password =='' )
    {
       this.ToastrService.error('Please Fill Mandatory Fields', 'Fields Are Empty', {
       timeOut: 2000
     });
  }
  else{
    //this.service.enableJobSeeker=true;
    //this.jobSeekerService.getJobSeekerByID(this.service.loginUserId).subscribe(res=>{
      //  console.log(" Seeker id got in sign in : ",res)});

    this.service.CheckLoginInfo(form.value).subscribe(res=>{

      console.log(res['Status']);
       
      if(res['Status']=="Success")
      {
        this.service.uType="J";
        this.service.userOrganization="";
        this.service.isAuthenticated=true;
        this.service.enableJobSeeker=true;
        this.service.enableJobPost=false;
        //console.log("Changed value to true :"+this.service.isAuthenticated);
        this.resetForm(form);
        this.ToastrService.success( 'success','Login Successful',{
          timeOut: 2000,
            });
            console.log("value of login userid before in sign in function is",this.service.loginUserId+"....");
            this.routerBtn.navigate(['/Home/']);
       // this.routerBtn.navigate(["/Home/"+this.service.loginUserId]);
      }
      else
      {
        this.service.loginUserId=null;
        this.service.uType="";
        this.service.userOrganization="";
        this.service.isAuthenticated=false;
        this.service.enableJobSeeker=false;
        this.service.enableJobPost=false;
        //console.log("value of loginUserid before in sign in function else block is",this.service.loginUserId+"....");
        this.resetForm(form);
        this.ToastrService.warning( 'Incorrect Fields','Login Not Possible',{
          timeOut: 2000,
     });
        this.routerBtn.navigate(['/users/']);
      }
      }) 
  }
  
  }

  
}
ValidEmployerSignIn(form:NgForm){
  if(form != null)
  {
    form.value.userType="E"; 
    if(this.service.formData.userName == undefined || this.service.formData.userName == '' || this.service.formData.password == undefined || this.service.formData.password =='')
    {
       this.ToastrService.error('Please Fill Mandatory Fields', 'Fields Are Empty', {
       timeOut: 2000
     });
    }
  else{    
    //console.log("Inside form");
    this.service.enableJobPost=true;
    
    this.service.CheckLoginInfo(form.value).subscribe(res=>{  
      console.log("Checking for authentication")   ; 
      if(res['Status']=="Success")
      {
        this.service.userOrganization=this.service.formData.userName;
        this.service.uType="E";
        this.service.loginUserId=null;
        this.service.isAuthenticated=true;
        this.service.enableJobSeeker=false;
        this.service.enableJobPost=true;

       // console.log("Changed value to true"+this.service.isAuthenticated);
        console.log("Organization Name : " + this.service.userOrganization)
        this.resetForm(form);
        this.ToastrService.success( 'success','Login Successful',{
          timeOut: 2000,
            });
            this.routerBtn.navigate(['/Home/']);
       // this.routerBtn.navigate(["/Home/"+this.service.userOrganization]);
      }
      else
      {
        this.service.userOrganization="";
        this.service.uType="";
        this.service.loginUserId=null;
        this.service.isAuthenticated=false;
        this.service.enableJobSeeker=false;
        this.service.enableJobPost=false;
        this.resetForm(form);
        this.routerBtn.navigate(['/users/']);
        this.ToastrService.warning( 'Incorrect Fields','Login Not Possible',{
          timeOut: 2000,
     }); }  })
}
}
}
}
