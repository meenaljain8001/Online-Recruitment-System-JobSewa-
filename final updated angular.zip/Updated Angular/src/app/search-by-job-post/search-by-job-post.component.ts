import { Component, OnInit } from '@angular/core';
import { JobpostService } from '../shared/jobpost.service';
import { AppliedJobs } from '../shared/applied-jobs.model';
import { AppliedJobsService } from '../shared/applied-jobs.service';
import { ToastrService } from 'ngx-toastr';
import { JobSeeker } from '../shared/job-seeker.model';
import { JobSeekerService } from '../shared/job-seeker.service';


@Component({
  selector: 'app-search-by-job-post',
  templateUrl: './search-by-job-post.component.html',
  styleUrls: ['./search-by-job-post.component.scss']
})
export class SearchByJobPostComponent implements OnInit {
  callResume:boolean=false;
  sid:number;
  jobSeekerList:Array<JobSeeker>=[];
  
  constructor(private searchdataService:JobpostService,public service:AppliedJobsService,private toastr:ToastrService,private seekerService:JobSeekerService) { 
    this.callResume=false;
  }
  model : any={};    
  job:any;  
  ngOnInit(): void {  

    this.service.getList().subscribe(res=>
      {
        this.service.list=res as AppliedJobs[];
        console.log(res);
        for(let i=0;i<this.service.list.length;i++)
        {
          this.seekerService.getJobSeekerByID(this.service.list[i].seekerId).subscribe((res2:JobSeeker)=>
            {
              
              this.jobSeekerList.push(res2);
            })
        }
        console.log(this.jobSeekerList)
      });
  }

  

  populateForm(jobSeeker: JobSeeker) {
    this.seekerService.formData = Object.assign({}, jobSeeker);
  }

  showResume(id: number) {
    this.sid=id;
   this.callResume=true;
  }


 
  searchAppliedJobsByExperience() {  
  
    this.searchdataService.searchAppliedJobsByExperience(this.model).subscribe((res: any) => {  
            
        this.job=res;   
        console.log(this.job);   
        
    })  
  }  
  searchAppliedJobsBySkills() {  
  
    this.searchdataService.searchAppliedJobsBySkills(this.model).subscribe((res: any) => {  
            
        this.job=res;   
        console.log(this.job);   
    })  
  } 
  
  searchAppliedJobsByDesignation() {  
    this.searchdataService.searchAppliedJobsByDesignation(this.model).subscribe((res: any) => {  
            
        this.job=res;   
        console.log(this.job);   
    })  
  }  

  searchAppliedJobsByLocation() {  
  
    this.searchdataService.searchAppliedJobsByLocation(this.model).subscribe((res: any) => {  
            
        this.job=res;   
        console.log(this.job);   
    })  
  }  

}
