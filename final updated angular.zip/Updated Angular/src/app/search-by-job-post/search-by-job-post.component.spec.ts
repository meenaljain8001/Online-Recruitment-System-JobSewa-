import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchByJobPostComponent } from './search-by-job-post.component';

describe('SearchByJobPostComponent', () => {
  let component: SearchByJobPostComponent;
  let fixture: ComponentFixture<SearchByJobPostComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchByJobPostComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchByJobPostComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
