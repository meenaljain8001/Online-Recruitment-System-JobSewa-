import { AppliedJobs } from './applied-jobs.model';

describe('AppliedJobs', () => {
  it('should create an instance', () => {
    expect(new AppliedJobs()).toBeTruthy();
  });
});
