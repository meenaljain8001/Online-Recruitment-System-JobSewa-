
import { Injectable } from '@angular/core';
import { Users } from './users.model';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UsersService {
  formData  : Users;
  list : Users[];
  uType:string="";
 
  userOrganization: string="";
  loginUserId:number=null;
  isAuthenticated:boolean=false;

  readonly rootURL ="http://localhost:49754/api";
  enableJobSeeker: boolean=false;
  enableJobPost: boolean=false;

  constructor(private http : HttpClient) { }

  postUsers(formData : Users){

   return this.http.post(this.rootURL+'/Users',formData);
  }

  
  CheckLoginInfo(user:Users){  
  //  this.userSub.next(user);
    return this.http.post(this.rootURL +'/Users/CheckLoginInfo',user);  
  }

  refreshList(){
    this.http.get(this.rootURL+'/Users')
    .toPromise().then(res => this.list = res as Users[]);
  }

  deleteLoginInfo(id: number)
  {
    this.http.delete(this.rootURL+'Users'+id);
  }

  createUser(formData: Users): Observable<Users> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this.http.post<Users>(this.rootURL + '/Users/', formData, httpOptions);
  }
}