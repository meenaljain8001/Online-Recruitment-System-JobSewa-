export class ResumeDetails {
    seekerResumeId:number;
    seekerXQualification:string;
    seekerXIIQualification:string;
    seekerHighestDegree:string;
    seekerSkills:string;
    seekerExperience:number;
    seekerProjects:string;
}
    
