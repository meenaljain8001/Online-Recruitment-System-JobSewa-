import { JobSeeker } from './job-seeker.model';

describe('JobSeeker', () => {
  it('should create an instance', () => {
    expect(new JobSeeker()).toBeTruthy();
  });
});
