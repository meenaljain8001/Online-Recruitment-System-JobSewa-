import { Injectable } from '@angular/core';
import { JobPost } from './jobpost.model';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class JobpostService {
isCollapsed:boolean=true;
  formData  : JobPost;
  list : JobPost[];
  listOfParticularOrg:JobPost[];
  readonly rootURL ="http://localhost:49754/api"

  constructor(private http : HttpClient) { }

  postJobPost(formData : JobPost){
   return this.http.post(this.rootURL+'/JobPosts',formData);
  }
  
  refreshList(){
    this.http.get(this.rootURL+'/JobPosts')
    .toPromise().then(res => this.list = res as JobPost[]);
  }

  putJobPost(formData : JobPost){
    return this.http.put(this.rootURL+'/JobPosts/'+formData.jobId,formData); 
   }

   getJobPostByID(id:number)
   {
    this.http.get(this.rootURL+'/JobPosts'+id);
   }

   deleteJobPost(id : number){
    return this.http.delete(this.rootURL+'/JobPosts/'+id);
   }

   checkLoginByOrganization(model: any)
   {
     return this.http.post<any>(this.rootURL +'/JobPosts/checkLoginByOrganization',model); 
   }
 
   searchJobsByOrganization(model :any)
   {
     return this.http.post<any>(this.rootURL +'/JobPosts/searchJobsByOrganization',model); 
   }
 

   searchAppliedJobsByDesignation(model : any){  
    return this.http.post<any>(this.rootURL +'/JobPosts/searchAppliedJobsByDesignation',model);    
   }
   searchAppliedJobsByExperience(model : any){  
     return this.http.post<any>(this.rootURL +'/JobPosts/searchAppliedJobsByExperience',model);    
    }
    searchAppliedJobsByLocation(model : any){  
     return this.http.post<any>(this.rootURL +'/JobPosts/searchAppliedJobsByLocation',model);    
    }
    searchAppliedJobsBySkills(model : any){  
     return this.http.post<any>(this.rootURL +'/JobPosts/searchAppliedJobsBySkills',model);    
    }
   



}
