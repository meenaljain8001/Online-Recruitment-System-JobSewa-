export class JobSeeker {
    seekerId : number;
    seekerName :string;
    seekerAddress :string;
    seekerEmail :string;
    seekerPhoneNo :string;
    seekerPhoto :any;
   //     public Nullable<int> seekerResumeId : number;
   seekerXQualification:string;
   seekerXIIQualification:string;
    seekerHighestDegree:string;
    seekerSkills:string;
    seekerExperience:number;
    seekerProjects:string

}
