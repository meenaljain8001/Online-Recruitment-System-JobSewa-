export class Users {
  userID:number;
  userName:string;
  password:string;
  userType:string;
  }

  