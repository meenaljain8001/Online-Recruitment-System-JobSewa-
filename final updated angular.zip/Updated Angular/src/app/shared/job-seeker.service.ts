import { Injectable } from '@angular/core';
import { JobSeeker } from './job-seeker.model';
import { HttpClient } from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class JobSeekerService {
collapse:boolean=true;
  formData  : JobSeeker;
  list : JobSeeker[];
  seekerID:any;
  readonly rootURL ="http://localhost:49754/api";


  constructor(private http : HttpClient) { }

  postJobSeeker(formData : JobSeeker){
   return this.http.post(this.rootURL+'/JobSeekers',formData);
  }

  getJobSeekerByID(id:number)
  {
    return this.http.get(this.rootURL+'/JobSeekers/'+id);
  }

  refreshList(){
    this.http.get(this.rootURL+'/JobSeekers')
    .toPromise().then(res => this.list = res as JobSeeker[]);
  }

  putJobSeeker(formData : JobSeeker){
    console.log("Inside Service: "+formData.seekerId);
    return this.http.put(this.rootURL+'/JobSeekers/'+formData.seekerId,formData); 
   }

   deleteJobSeeker(id : number){
    return this.http.delete(this.rootURL+'/JobSeekers/'+id);
   }
   searchJobsByExperience(model : any){  
    return this.http.post<any>(this.rootURL +'/JobSeeker/searchJobsByExperience',model);    
   }
   searchJobsByDesignation(model : any){  
    return this.http.post<any>(this.rootURL +'/JobSeeker/searchJobsByDesignation',model);    
   }
   searchJobsBySkills(model : any){  
    return this.http.post<any>(this.rootURL +'/JobSeeker/searchJobsBySkills',model);    
   }
   searchJobsByLocation(model : any){  
    return this.http.post<any>(this.rootURL +'/JobSeeker/searchJobsByLocation',model);    
   }


}
