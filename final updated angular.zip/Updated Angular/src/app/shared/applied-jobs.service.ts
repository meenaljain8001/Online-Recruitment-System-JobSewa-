import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AppliedJobs } from './applied-jobs.model';

@Injectable({
  providedIn: 'root'
})
export class AppliedJobsService {

  readonly rootURL ="http://localhost:49754/api";

  formData: AppliedJobs;
  list:AppliedJobs[]=[];
  constructor(private http : HttpClient) { }

 postAppliedJobs(formData : AppliedJobs){
   return this.http.post(this.rootURL+'/AppliedJobs',formData);
  }

  getList()
  {
    return this.http.get(this.rootURL+"/AppliedJobs");
  }
}
