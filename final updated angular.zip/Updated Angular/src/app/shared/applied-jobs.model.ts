export class AppliedJobs {
    seekerId:number;
    jobId:number;
    appliedId:number;
}
