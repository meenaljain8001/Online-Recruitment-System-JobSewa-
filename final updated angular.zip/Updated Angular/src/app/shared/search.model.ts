export class Search {
jobId :number;
jobDesignation :string;
jobExperience :number;
jobLocation :string
jobOrganization:string; 
jobPackage:string; 
jobType :string;
jobCreationDate :Date;
seekerId :number;
seekerName :string;
seekerAddress :string;
seekerEmail :string;
seekerPhoneNo :string
}
