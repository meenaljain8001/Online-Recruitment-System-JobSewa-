import { Jobpost } from './jobpost.model';

describe('Jobpost', () => {
  it('should create an instance', () => {
    expect(new Jobpost()).toBeTruthy();
  });
});
