import { ResumeDetails } from './resume-details.model';

describe('ResumeDetails', () => {
  it('should create an instance', () => {
    expect(new ResumeDetails()).toBeTruthy();
  });
});
