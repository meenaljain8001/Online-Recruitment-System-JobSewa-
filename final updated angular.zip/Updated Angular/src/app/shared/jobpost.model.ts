export class JobPost {
    jobId:number;
    jobDesignation:string;
    jobExperience:number;
    jobLocation:string;
    jobOrganization:string;
    jobPackage:string;
    jobType:string;
    jobCreationDate:Date;
  }
  