import { AppliedJojbs } from './applied-jojbs.model';

describe('AppliedJojbs', () => {
  it('should create an instance', () => {
    expect(new AppliedJojbs()).toBeTruthy();
  });
});
