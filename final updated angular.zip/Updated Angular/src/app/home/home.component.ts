import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { UsersService } from '../shared/users.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  userType:any;
  constructor(private route:ActivatedRoute, private usersService:UsersService) { }

  ngOnInit(): void {
    console.log("users authentication : ",this.usersService.isAuthenticated);
    console.log("login user id :",this.usersService.loginUserId);
    console.log("user organization name :",this.usersService.userOrganization);
    console.log("user type :" ,this.usersService.uType);
    console.log("enable job seeker :",this.usersService.enableJobSeeker);
    console.log("enable job post :",this.usersService.enableJobPost);

    if(this.route.snapshot.params['seekerID']){
      console.log("Seeker ID is: ", this.route.snapshot.params['seekerID']);
      this.usersService.loginUserId=this.route.snapshot.params['seekerID'];
    }
    if(this.route.snapshot.params['organizationName'])
    {
      console.log("sbjanlcsakn"+this.route.snapshot.params['organizationName'])
      this.usersService.userOrganization=this.route.snapshot.params['organizationName'];
    }
  
  }
}
