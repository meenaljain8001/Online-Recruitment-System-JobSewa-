import { Component, OnInit } from '@angular/core';
import { JobpostService } from '../shared/jobpost.service';
import { ToastrService } from 'ngx-toastr';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { JobSeekerService } from '../shared/job-seeker.service';
import { UsersService } from '../shared/users.service';
import { AppliedJobsService } from '../shared/applied-jobs.service';
import { AppliedJobs } from '../shared/applied-jobs.model';


@Component({
  selector: 'app-apply-jobs',
  templateUrl: './apply-jobs.component.html',
  styleUrls: ['./apply-jobs.component.css']
})
export class ApplyJobsComponent implements OnInit {

  seekerId:any;
  Formdata: any;
  listOfAppliedJobs:AppliedJobs[]=[];

  constructor(public service:JobpostService,private appliedJobsService:AppliedJobsService,private usersService:UsersService,
    public jobSeekerService : JobSeekerService,private toastr:ToastrService, private route:Router) { }

  

  ngOnInit(): void {

      console.log("Inside APply Jobs : "+this.usersService.loginUserId);

    this.service.refreshList();

  }

  checkForRepetition(jobID:number)
  {
this.appliedJobsService.getList().subscribe(res=>{
  console.log("response is:",res)
  this.appliedJobsService.list = Object.assign({}, res as AppliedJobs[]);
})
this.appliedJobsService.list.forEach(element => console.log("Element found:",element));

return true;
  }
// Removed all td's calling populate form on click event
 // populateForm(jobPost: JobPost) {
   // this.service.formData = Object.assign({}, jobPost);
 // }

  applyForJob(id: number) {
    if(this.usersService.loginUserId != null)
    {
      console.log("seekerId : "+this.usersService.loginUserId+"JobId :"+ id+"random number:"+this.getRandomNumber());
      this.appliedJobsService.postAppliedJobs({seekerId:this.usersService.loginUserId,jobId:id,appliedId:this.getRandomNumber()})
      .subscribe(res=>{
        this.toastr.success('Your Request has been Accepted', 'Proceed forward for more');
        this.service.refreshList();
      }
        );
    }
    else{
      this.toastr.warning('Please Login To Continue', 'Error');
      this.route.navigate(["/users/"]);
    }
  }
  
  getRandomNumber() {
    const random = Math.floor(Math.random() * (999999 - 100000)) + 100000;
    return random;
    
}

}
