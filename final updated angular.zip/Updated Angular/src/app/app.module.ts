import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { platformBrowserDynamic} from '@angular/platform-browser-dynamic';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { HeaderComponent } from './header/header.component';
import { UsersComponent } from './users/users.component';

import { Routes, RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { ContactUsComponent } from './contact-us/contact-us.component';

import { ToastrModule } from 'ngx-toastr';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { JobSeekerService } from './shared/job-seeker.service';
import { JobSeekersComponent } from './job-seekers/job-seekers.component';
import { JobSeekerComponent } from './job-seekers/job-seeker/job-seeker.component';
import { JobSeekerListComponent } from './job-seekers/job-seeker-list/job-seeker-list.component';

import { JobpostService } from './shared/jobpost.service';

import { UsersService } from './shared/users.service';

import { MatFormFieldModule } from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import {MatTabsModule} from '@angular/material/tabs';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatToolbarModule,} from '@angular/material/toolbar'
import { MatNativeDateModule } from '@angular/material/core';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { MatButtonModule } from '@angular/material/button';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatTooltipModule } from '@angular/material/tooltip';
import {MatSelectModule} from '@angular/material/select';

import { ResumedetailsComponent } from './job-seekers/resumedetails/resumedetails.component';
import { JobPostsComponent } from './job-posts/job-posts.component';
import { JobPostComponent } from './job-posts/job-post/job-post.component';
import { JobPostListComponent } from './job-posts/job-post-list/job-post-list.component';
import { ApplyJobsComponent } from './apply-jobs/apply-jobs.component';
import { ListofJobSeekerComponent } from './listof-job-seeker/listof-job-seeker.component';
import { SearchByJobPostComponent } from './search-by-job-post/search-by-job-post.component';
import { SearchByJobSeekerComponent } from './search-by-job-seeker/search-by-job-seeker.component';
import { LogOutComponent } from './log-out/log-out.component';





@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    JobPostComponent,
    HeaderComponent,
    UsersComponent,
    JobSeekersComponent,
    JobSeekerComponent,
    JobSeekerListComponent,
    JobPostListComponent,
    SearchByJobPostComponent,
    SearchByJobSeekerComponent,
    ResumedetailsComponent,
    JobPostsComponent,
    ApplyJobsComponent,
    ListofJobSeekerComponent,
    LogOutComponent    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot(),
    FormsModule,
    MatTabsModule,
    MatExpansionModule,
    ReactiveFormsModule, FormsModule,
    MatTabsModule,
    MatExpansionModule,
    ReactiveFormsModule,MatFormFieldModule,MatInputModule,MatToolbarModule,MatNativeDateModule,MatDatepickerModule,
    MatButtonModule,MatSelectModule,
     FormsModule,
     ReactiveFormsModule,
     MatMenuModule,
     MatIconModule,
     MatCardModule,
     MatSidenavModule,
     MatTooltipModule,
     
  ],
  exports: [
    MatSelectModule,
    MatMenuModule,
    MatIconModule,
    MatCardModule,
    MatSidenavModule,
    MatTooltipModule,
  ],
  
  providers: [JobSeekerService,JobpostService,UsersService],
  bootstrap: [AppComponent],
}
)
export class AppModule
{}

