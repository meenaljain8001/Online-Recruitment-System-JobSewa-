import { Component, OnInit } from '@angular/core';
import { JobSeekerService } from '../shared/job-seeker.service';
import { UsersService } from '../shared/users.service';
import { AppliedJobsService } from '../shared/applied-jobs.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { JobpostService } from '../shared/jobpost.service';
import { AppliedJobs } from '../shared/applied-jobs.model';

@Component({
  selector: 'app-search-by-job-seeker',
  templateUrl: './search-by-job-seeker.component.html',
  styleUrls: ['./search-by-job-seeker.component.scss']
})
export class SearchByJobSeekerComponent implements OnInit {
listOfAppliedJobs:AppliedJobs[];
  constructor(public service:JobpostService,private searchdataService:JobSeekerService,private usersService:UsersService
    ,private appliedJobsService:AppliedJobsService,private toastr:ToastrService, private route:Router) { }  
  model : any={};    
  job:any;  
  ngOnInit(): void {   }  
  applyForJob(id: number) {
    if(this.checkForRepetition(id))
    {
    if(this.usersService.loginUserId != null)
    {
      console.log("seekerId : "+this.usersService.loginUserId+"JobId :"+ id+"random number:"+this.getRandomNumber());
      this.appliedJobsService.postAppliedJobs({seekerId:this.usersService.loginUserId,jobId:id,appliedId:this.getRandomNumber()})
      .subscribe(res=>{
        //console.log(res)
        this.toastr.success('Your Request has been Accepted', 'Proceed forward for more');
        //this.service.refreshList();
      }
        );
    }
    else{
      this.toastr.warning('Please Login To Continue', 'Error');
      this.route.navigate(["/users/"]);
    } 
  } 
  else{
    this.toastr.info('You have already applied for this job!!!!!!!', 'Warning');
  }
  }
  getRandomNumber() {
    const random = Math.floor(Math.random() * (999999 - 100000)) + 100000;
    return random;
    
}
  searchJobsByExperience() {  
  
    this.searchdataService.searchJobsByExperience(this.model).subscribe((res: any) => {  
            
        this.job=res;   
      //  console.log(this.job);   
        
    })  
  }  
  searchJobsBySkills() {  
  
    this.searchdataService.searchJobsBySkills(this.model).subscribe((res: any) => {  
            
        this.job=res;   
        //console.log(this.job);   
    })  
  } 
  searchJobsByDesignation() {  
    this.searchdataService.searchJobsByDesignation(this.model).subscribe((res: any) => {  
            
        this.job=res;   
        //console.log(this.job);   
    })  
  }  
  searchJobsByLocation() {  
  
    this.searchdataService.searchJobsByLocation(this.model).subscribe((res: any) => {  
            
        this.job=res;   
        //console.log(this.job);   
    })  
  }  
  checkForRepetition(jobID:number)
  {
    this.appliedJobsService.getList().subscribe(resList=>{
  this.listOfAppliedJobs=resList as AppliedJobs[];
})
for(let i=0;i<this.listOfAppliedJobs.length;i++)
{
  console.log("seeker id:",this.listOfAppliedJobs[i].seekerId,"Job Id:",this.listOfAppliedJobs[i].jobId);
  if(this.listOfAppliedJobs[i].seekerId==this.usersService.loginUserId && this.listOfAppliedJobs[i].jobId==jobID)
  {
    return false;
  }
}
return true;
  }

}
