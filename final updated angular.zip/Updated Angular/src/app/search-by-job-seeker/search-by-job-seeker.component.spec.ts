import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchByJobSeekerComponent } from './search-by-job-seeker.component';

describe('SearchByJobSeekerComponent', () => {
  let component: SearchByJobSeekerComponent;
  let fixture: ComponentFixture<SearchByJobSeekerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchByJobSeekerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchByJobSeekerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
