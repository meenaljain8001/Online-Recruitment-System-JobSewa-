import { Component, OnInit } from '@angular/core';
import { JobpostService } from 'src/app/shared/jobpost.service';
import { ToastrService } from 'ngx-toastr';
import { NgForm } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { UsersService } from 'src/app/shared/users.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-job-post',
  templateUrl: './job-post.component.html',
  styleUrls: ['./job-post.component.css']
})
export class JobPostComponent implements OnInit {

  model :any={};
  list: any;

  constructor(public service:JobpostService,private usersService:UsersService,
    private toastr:ToastrService, private http:HttpClient,private routeBtn:Router) { }

    ngOnInit() {
      this.resetForm();
    }
  
    resetForm(form?: NgForm) {
      if (form != null)
      {
        form.resetForm();
      }
        this.service.formData = {
          jobId: null,
          jobDesignation: '',
          jobExperience: null,
          jobOrganization :'',
          jobPackage :'',
          jobType :'',
          jobLocation:'',
          jobCreationDate:null
      }
    }
    
  
    onSubmit(form: NgForm) {
      this.service.isCollapsed=false;
     //console.log("Job Id:",form.value.jobId);
      //console.log("Oranization name from form is:",form.value.jobOrganization);
      //console.log("Oranization name from usersService is:",this.usersService.userOrganization);
      
      if (form.value.jobId== null)
      {
        if(this.usersService.userOrganization!= "")
        {
      if(form.value.jobOrganization==this.usersService.userOrganization)
      {
        console.log("same organization name found")
        this.insertRecord(form);
        
      }
      else{
        this.toastr.warning("Enter Correct value of Job Organization:","Invalid Value Recieved");
      }
    }
    else
    {
      this.toastr.warning("Please Login To Add Details","Error");
      this.routeBtn.navigate(['/users/']);
    }
    }
      else
      {  
          if(form.value.jobOrganization==this.usersService.userOrganization)
          {
            console.log("same organization name found")
            this.updateRecord(form);
            
          }
          else{
            this.toastr.warning("Enter Correct value of Job Organization:","Invalid Value Recieved");
          }
      }      
    }
  
    insertRecord(form: NgForm) {
      this.service.postJobPost(form.value).subscribe(res => {
        console.log(res);
        this.toastr.success('Inserted successfully', 'Data Registered');
        this.resetForm(form);
        this.getJobPostList();
        this.service.refreshList();
      });
    }

    
  getJobPostList()
  {
    console.log("User Organization :"+ this.usersService.userOrganization);
    this.model.jobOrganization = this.usersService.userOrganization;
    this.service.searchJobsByOrganization(this.model).subscribe((res:any)=>
    {
    console.log(res);
    this.list = res ;
    }
    )
  }
  
    updateRecord(form: NgForm) {
      console.log("Inside Update ");
      this.service.putJobPost(form.value).subscribe(res=>{
        this.toastr.info('Updated successfully', 'Data Registered');
        this.resetForm(form);
        this.service.refreshList();
      });
    


  

}
}
