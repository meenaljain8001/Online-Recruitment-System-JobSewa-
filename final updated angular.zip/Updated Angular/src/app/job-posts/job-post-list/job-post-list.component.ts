import { Component, OnInit } from '@angular/core';
import { JobpostService } from 'src/app/shared/jobpost.service';
import { ToastrService } from 'ngx-toastr';
import { JobPost } from 'src/app/shared/jobpost.model';
import { UsersService } from 'src/app/shared/users.service';

@Component({
  selector: 'app-job-post-list',
  templateUrl: './job-post-list.component.html',
  styleUrls: ['./job-post-list.component.css']
})
export class JobPostListComponent implements OnInit {

  model :any={};
  constructor(public service:JobpostService,private toastr:ToastrService,private userService : UsersService) { }

  ngOnInit(): void {
    this.getJobPostList();
  }

  ToggleChanges()
  {
    this.getJobPostList();
    this.service.isCollapsed=!this.service.isCollapsed;
  }
  getJobPostList()
  {
    console.log("User Organization :"+ this.userService.userOrganization);
    this.model.jobOrganization = this.userService.userOrganization;
    this.service.searchJobsByOrganization(this.model).subscribe((res:any)=>
    {
    console.log(res);
    this.service.listOfParticularOrg = res ;
    }
    )
  }

  populateForm(jobPost: JobPost) {
    this.service.formData = Object.assign({}, jobPost);
  }

  onDelete(id: number) {
    if (confirm('Are you sure to delete this record?')) {
      this.service.deleteJobPost(id).subscribe(res => {
        this.service.refreshList();
        this.getJobPostList();
        this.toastr.warning('Deleted successfully', 'EMP. Register');
      });
    }

  }
}
