import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListofJobSeekerComponent } from './listof-job-seeker.component';

describe('ListofJobSeekerComponent', () => {
  let component: ListofJobSeekerComponent;
  let fixture: ComponentFixture<ListofJobSeekerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListofJobSeekerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListofJobSeekerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
