import { Component, OnInit } from '@angular/core';
import { JobSeekerService } from '../shared/job-seeker.service';
import { ToastrService } from 'ngx-toastr';
import { JobSeeker } from '../shared/job-seeker.model';
import { AppliedJobs } from '../shared/applied-jobs.model';
import { AppliedJobsService } from '../shared/applied-jobs.service';
import { JobPost } from '../shared/jobpost.model';
import { JobpostService } from '../shared/jobpost.service';
import { UsersService } from '../shared/users.service';

@Component({
  selector: 'app-listof-job-seeker',
  templateUrl: './listof-job-seeker.component.html',
  styleUrls: ['./listof-job-seeker.component.css']
})
export class ListofJobSeekerComponent implements OnInit {
callResume:boolean=false;
sid:number;
model:any={};
jobSeekerList:JobSeeker[];
  constructor(public service:AppliedJobsService,private toastr:ToastrService
    ,private seekerService:JobSeekerService,public jobPostService:JobpostService,private usersService:UsersService) { 
    this.callResume=false;
  }

  ngOnInit(): void {
    this.refreshList();
  }

  refreshList()
  {
    this.model.jobOrganization=this.usersService.userOrganization;
this.jobPostService.checkLoginByOrganization(this.model).subscribe(res=>{
console.log("Result for this is:",res);
this.jobSeekerList=res as JobSeeker[];
})
    
  }

  populateForm(jobSeeker: JobSeeker) {
    this.seekerService.formData = Object.assign({}, jobSeeker);
  }

  showResume(id: number) {
    this.sid=id;
   this.callResume=true;
  }
}
