import { Injectable } from '@angular/core';
import { JobSeeker } from 'src/app/model/job-seeker.model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class JobseekerService {

  jobSeeker : JobSeeker;

  readonly rootURL ="http://localhost:52296/api/";

  constructor(private http:HttpClient) {

   }

   getAllJobSeekersDetails(): Observable<JobSeeker[]> {
    return this.http.get<JobSeeker[]>(this.rootURL + '/JobSeekers');
  }


   addJobSeekerDetails(jobSeekerInfo: JobSeeker)
   {

     //We will return the observable from POST method to the calling function
                 //URI for Web API's Method
       return this.http.post(this.rootURL+'',jobSeekerInfo);
   }
}
